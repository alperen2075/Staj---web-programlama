import React from 'react';
import './App.css';
import "bootstrap/dist/css/bootstrap.min.css";
import Header from "./components/layouts/Header";
import Navigationbar from "./components/layouts/Navigationbar";
import Article from "./components/layouts/Article";
import Table from "./components/layouts/Table";
import { CircularProgressbar } from 'react-circular-progressbar';
import 'react-circular-progressbar/dist/styles.css';

function App() {
  return (
    <div className="App ">
      <Header />
      <div className="container">        
        <div className="row">
          <div className="col-md-3"><Navigationbar /></div>
          <div className="col-md-9">
            <div className="row"><Article /></div>
            <div className="row"><Table /></div>
          </div>


        </div>
      </div>



    </div>
  );
}

export default App;
