import React from "react";
import styled from "styled-components";

const Table = () => {
  return (
    <div className="container">
      <MainContainer className="rounded-lg ">
        <TopContainer className="rounded-top "><h6>Terminal Listesi</h6></TopContainer>
        <div className="row">
          <div className="col-sm-6 ">
            <div className="container">
              <div className="border search rounded">
                <input
                  type="text"
                  className=" input-group-sm "
                  placeholder="Tablo İçinde Ara"
                />
                <i className="fas fa-search fa-1x"></i>
              </div>
              <button type="button " className="button btn btn-secondary">
                <i className="fas fa-sync-alt fa-xs refresh "></i>
              </button>
            </div>
          </div>
        </div>
        <TableContainer className="rounded">
        <div class="table-wrapper-scroll-y my-custom-scrollbar">
          <table className="table table-bordered table-striped mb-0 table-sm">
            <tr>
              <th>SAN</th>
              <th>Açıklama</th>
              <th>ESN</th>
              <th>Check Digit</th>
              <th>Paketi</th>
              <th>IP</th>
              <th>Kapsam Alanı</th>
              <th>Durumu</th>
              <th>Oluşturulma Tarihi</th>
              <th>Aktivasyon Tarihi</th>
              <th>İptal Tarihi</th>
              <th>En Son İşlem Tarihi</th>
            </tr>
            <tr></tr>
            <tr></tr>
            <tr></tr>
            <tr></tr>
            <tr></tr>
            <tr></tr>
            <tr></tr>
            <tr></tr>
            <tr></tr>
            <tr></tr>
            <tr></tr>
            <tr></tr>
            <tr></tr>

          </table>
          </div>

        </TableContainer>
      </MainContainer>
    </div>
  );
};
export default Table;
//Main Container
const MainContainer = styled.article`
  background: #f5f5f5;
  width: 123%;
  height: 27rem;
  margin-left: -6.7rem;
  margin-top: 1%;
  font-weight: 50;
  font-size: 50;
`;
const TopContainer = styled.article`
  background: #c0c0c0;
  width: 100%;
  height: 2rem;
  padding-top: 1%;
  margin-bottom: 0.5%;
  h6 {
    color: #4682B4;
  }
`;
//Table Container
const TableContainer = styled.table`
  background: #d3d3d3;
  width: 98%;
  height: 81%;
  margin-top: 3%;
  margin-left: 1%;
`;
