import React from "react";
import styled from "styled-components";
import "react-circular-progressbar/dist/styles.css";
import ProgressBar from "./ProgressBar";
import { CircularProgressbar, buildStyles } from "react-circular-progressbar";

const Article = () => {
  return (
    <div className="container">
      <MainContainer className="rounded-lg ">
        <TopContainer className="rounded-top "><h6>Terminal İstatistik</h6></TopContainer>
        
        <div className="row">
          <div className="col-sm-3">
            <ProgressBar />
          </div>
          <div className="col-sm-3">
            <ProgressBar />
          </div>
          <div className="col-sm-3">
            <ProgressBar />
          </div>
          <div className="col-sm-3">
            <ProgressBar />
          </div>
        </div>
      </MainContainer>
    </div>
  );
};
export default Article;
//Main Container
const MainContainer = styled.article`
  background: #f5f5f5;
  width: 123%;
  height: 10rem;
  margin-left: -6.7rem;
  margin-top: 1%;
`;
const TopContainer = styled.article`
  background: #c0c0c0;
  width: 100%;
  height: 2rem;
  padding-top: 1%;

  margin-bottom: 1%;
  h6 {
    color: #4682B4;
  }
`;
//const CircularProgressbar=styled.progress``;
