import React from 'react';
import styled from 'styled-components';

 const Header = () => {
    return (
       <MainContainer className="shadow   ">
         <h5>Uydu Hizmetleri Çözüm Ortağı Portali</h5>
         <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQ5KTGXwJPBr-OIMj6xgGlnuKr39KrU26Gf6A&usqp=CAU" alt="logo"></img>
        </MainContainer>
         
    )
}
export default Header;
//Main Container
const MainContainer =styled.header`
background:white no-repeat center/cover;
height: 3rem;

h5{
  transform: translate(-50%, -50%);
  color: #4682B4;
  font-weight: 400;
  font-size:400;
  position: absolute;
  top: 3.5%;
  left: 35%;
}

img{
  width:3.5cm;
  position: absolute;
  top: 0%;
  left: 1%;
}
`;