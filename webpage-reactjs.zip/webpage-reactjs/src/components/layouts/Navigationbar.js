import React from "react";
import styled from "styled-components";

const Navigationbar = () => {
  return (
    <MainContainer className="container rounded-lg ">
      <h6>Terminal İşlemleri</h6>
      <ListContainer>

      <InsideContainer className="container rounded-lg "><h8>Yeni Terminal tanımla</h8></InsideContainer>
      <InsideContainer className="container rounded-lg "><h8>Paket Değiştir</h8></InsideContainer>
      <InsideContainer className="container rounded-lg "><h8>Ek Kota Tanımla</h8></InsideContainer>
      <InsideContainer className="container rounded-lg "><h8>Askıya Al</h8></InsideContainer>
      <InsideContainer className="container rounded-lg "><h8>Aktif Et</h8></InsideContainer>
      <InsideContainer className="container rounded-lg "><h8>İptal Et</h8></InsideContainer>
      <InsideContainer className="container rounded-lg "><h8>Yer Değiştir</h8></InsideContainer>
      <InsideContainer className="container rounded-lg "><h8>Donanım Değiştir</h8></InsideContainer>

      </ListContainer>
      

    </MainContainer>
  );
};
export default Navigationbar;
//Main Container
const MainContainer = styled.nav`
  background: #f5f5f5;
  width: 100%;
  height: 30rem;
  margin-left: -5.5rem;
  margin-top: 0.5rem;
  padding-top: 1%;

  h6 {
    color: #4682B4;
    position: absolute;
    left: 3%;
    top:2%;
  }
`;
const ListContainer = styled.nav`
  text-align:left;
  background: #f5f5f5;
  width: 100%;
  height: 90%;
  margin-top: 15%;

  h8 {
    color: #FFFFFF;
    font-size:14px;
  }
`;

//Inside Container
const InsideContainer = styled.nav`
  text-align:left;
  background: #4682B4;
  width: 100%;
  height: 7%;
  margin-top: 1%;
  padding-left:0.5rem;

  h8 {
    color: #FFFFFF;
  }
`;

